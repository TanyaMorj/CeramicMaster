﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToyStore
{
    public partial class Form1 : Form
    {
        SqlConnection conn;
        public Form1()
        {
            InitializeComponent();
            BaseCon baseCon = new BaseCon();
            baseCon.open_connection();
            conn = baseCon.get_connection();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            return_role();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            open_second_form("Гость");
        }

        void open_second_form(string role, string name="")
        {
            Form2 frm2;
            switch (role)
            {
                case "Администратор":
                    frm2 = new Form2(name:name, is_admin:true);
                    break;
                case "Менеджер":
                    frm2 = new Form2(name: name, is_manager:true);
                    break;
                case "Авторизированный клиент":
                    frm2 = new Form2(name: name);
                    break;
                default:
                    frm2 = new Form2();
                    break;
            }
            this.Hide();
            frm2.ShowDialog();
            this.Show();
        }

        void return_role()
        {
            SqlCommand cmd = new SqlCommand($"select Roles.role_name, Users.fio from Users inner join Roles on Users.rolee = Roles.id where Users.logn = '{textBox1.Text}' and Users.passwrd = '{textBox2.Text}'", conn);
            SqlDataReader rdr = cmd.ExecuteReader();
            if (rdr.Read())
            {
                open_second_form(rdr.GetString(0), rdr.GetString(1));
            }

            else
            {
                MessageBox.Show("Неверный логин или пароль", "Неверные данные", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
                
            rdr.Close();
        }
    }
}
