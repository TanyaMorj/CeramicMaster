﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToyStore
{
    public partial class Form2 : Form
    {
        bool is_manager;
        bool is_admin;
        SqlConnection conn;
        public Form2(string name="", bool is_manager = false, bool is_admin = false)
        {
            BaseCon bc = new BaseCon();
            bc.open_connection();
            conn = bc.get_connection();
            this.is_manager = is_manager;
            this.is_admin = is_admin;
            InitializeComponent();
            label15.Text = name;
            fill_the_access();
            fill_the_panel();
            fill_the_combobox();
        }

        private void fill_the_combobox()
        {
            comboBox3.Items.Clear();
            comboBox3.Items.Add("Все поставщики");
            comboBox3.Text = "Все поставщики";
            SqlCommand cmd = new SqlCommand("SELECT DISTINcT [deliver_name] FROM [Deliver]", conn);

            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                comboBox3.Items.Add(rdr.GetString(0));
            }
            rdr.Close();
            comboBox1.Items.Add("Возрастание");
            comboBox1.Items.Add("Убывание");
            comboBox2.Items.Add("Возрастание");
            comboBox2.Items.Add("Убывание");
        }

        private void fill_the_access()
        {
            panel1.Visible = is_admin || is_manager;
            panel3.Visible = is_admin;
        }

        private void fill_the_panel(string new_usl="")
        {
            panel2.Controls.Clear();
            SqlCommand cmd = new SqlCommand("select [Products].[id],[art],[product_name],Unit_measuremnt.[unit_name],[price],Deliver.[deliver_name]      ,Creator.creator_name      ,Categories.category_name      ,[discont]      ,[countt]      ,[info]      ,[photo] from ((([Products] inner join Unit_measuremnt on Unit_measuremnt.id = [Products].unit_meas) inner join Deliver on Products.deliver = Deliver.id)      inner join Creator on Creator.id = Products.creator) inner join Categories on Categories.id = Products.category" + new_usl, conn);

            SqlDataReader rdr = cmd.ExecuteReader();
            int i = 0;

            while (rdr.Read())
            {
                string new_price = "";
                string price = rdr.GetValue(4).ToString();
                string picka = "picture.png";
                Color color_for_dis = System.Drawing.Color.BurlyWood;
                Color color_for_price = System.Drawing.Color.White;
                Font font_for_price = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                Panel panel = new Panel();
                panel.Tag = rdr.GetInt32(0);
                panel.Location = new System.Drawing.Point(4, 4 + i*250);
                panel.Size = new System.Drawing.Size(1066, 221);
                picka = rdr.GetString(11);
                if (string.IsNullOrEmpty(picka))
                {
                    picka = "picture.png";
                }

                int discont = Convert.ToInt32(rdr.GetValue(8));
                if (discont > 0)
                {
                    new_price = (Convert.ToInt32(price) - Convert.ToInt32(price) * 0.01 * discont).ToString();
                    color_for_price = System.Drawing.Color.Red;
                    font_for_price = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Strikeout, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
                    if (discont > 17)
                        color_for_dis = System.Drawing.Color.NavajoWhite;

                }

                panel.Controls.AddRange(new Control[]
                { new Label{AutoSize = true,
                Font = new System.Drawing.Font("Arial", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204))), Location = new System.Drawing.Point(199, 4),
                Text = $"{rdr.GetString(7)} | {rdr.GetString(2)}"},

                new Label{AutoSize = true,
                Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))), Location = new System.Drawing.Point(199, 26),
                Text = $"Описание: {rdr.GetString(10)}"},

                new Label{AutoSize = true,
                Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))), Location = new System.Drawing.Point(199, 51),
                Text = $"Производитель: {rdr.GetString(6)}"},

                new Label{AutoSize = true,
                Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))), Location = new System.Drawing.Point(199, 78),
                Text = $"Поставщик: {rdr.GetString(5)}"},

                new Label{AutoSize = true,
                Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))), Location = new System.Drawing.Point(199, 104),
                Text = $"Цена:"},

                new Label{AutoSize = true,
                Font = font_for_price, Location = new System.Drawing.Point(294, 104),
                Text = $"{price}", BackColor = color_for_dis},

                new Label{AutoSize = true,
                Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))), Location = new System.Drawing.Point(336, 104),
                Text = $"{new_price}"},

                new Label{AutoSize = true,
                Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))), Location = new System.Drawing.Point(198, 126),
                Text = $"Единица измерения: {rdr.GetValue(3)}"},

                new Label{AutoSize = true,
                Font = new System.Drawing.Font("Arial Narrow", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))), Location = new System.Drawing.Point(198, 154),
                Text = $"Кол-во на складе: {rdr.GetValue(9)}"},

                new Label{Size = new System.Drawing.Size(222, 148),
                Font = new System.Drawing.Font("Arial Narrow", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))), Location = new System.Drawing.Point(807, 59), TextAlign = System.Drawing.ContentAlignment.MiddleCenter,
                Text = $"{rdr.GetValue(8)} %", BackColor = color_for_dis},

                new PictureBox{
                    Location = new System.Drawing.Point(4, 4),
            Size = new System.Drawing.Size(188, 149), Image = Image.FromFile(picka), SizeMode = PictureBoxSizeMode.Zoom
                }


                });
                if (is_admin)
                panel.Click += Panel_Click;

                panel2.Controls.Add(panel);
                i++;
            }
            rdr.Close();
        }

        private void Panel_Click(object sender, EventArgs e)
        {
            Panel panel = sender as Panel;
            Form3 frm3 = new Form3(Convert.ToInt32(panel.Tag));
            frm3.ShowDialog();
            fill_the_panel();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void set_new_pattern()
        {
            string name = string.IsNullOrEmpty(textBox4.Text) ? "%" : textBox4.Text;
            string sup = comboBox3.Text == "Все поставщики" ? "%" : comboBox3.Text;

            string cou = comboBox1.Text == "Возрастание" ? "ASC" : "Desc";
            string pri = comboBox2.Text == "Возрастание" ? "ASC" : "Desc";
            string pattent = $" where (product_name like N'%{name}%' or Unit_measuremnt.[unit_name] like N'%{name}%' " +
                $"or Creator.creator_name like N'%{name}%' or Categories.category_name like N'%{name}%'  or [info] like N'%{name}%') and Deliver.[deliver_name] like N'%{sup}%' " +
                $"order by price {pri}, countt {cou}";
            fill_the_panel(pattent);
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            set_new_pattern();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            set_new_pattern();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 form3 = new Form3();
            form3.ShowDialog();
            set_new_pattern();
            fill_the_panel();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 form4 = new Form4();
            form4.ShowDialog();
        }
    }
}
