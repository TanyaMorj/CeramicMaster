﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace ToyStore
{
    public partial class Form3 : Form
    {
        SqlConnection conn;
        string curr_img = "";
        string way_to_img = "";
        int id;
        public Form3(int id=-1)
        {
            this.id = id;
            BaseCon baseCon = new BaseCon();
            baseCon.open_connection();
            conn = baseCon.get_connection();
            InitializeComponent();
            fill_the_combobox();
            if (id > 0)
            {
                fill_the_spaces(id);
            }
        }

        private void fill_the_combobox()
        {
            SqlCommand cmd = new SqlCommand("SELECT DISTINcT [deliver_name] FROM [Deliver]", conn);

            SqlDataReader rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                comboBox2.Items.Add(rdr.GetString(0));
                comboBox2.Text = rdr.GetString(0);
            }
            rdr.Close();

            cmd = new SqlCommand("SELECT DISTINcT unit_name FROM Unit_measuremnt", conn);

            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                comboBox1.Items.Add(rdr.GetString(0));
                comboBox1.Text = rdr.GetString(0);
            }
            rdr.Close();

            cmd = new SqlCommand("SELECT DISTINcT creator_name FROM Creator", conn);

            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                comboBox3.Items.Add(rdr.GetString(0));
                comboBox3.Text = rdr.GetString(0);
            }
            rdr.Close();

            cmd = new SqlCommand("SELECT DISTINcT category_name FROM Categories", conn);

            rdr = cmd.ExecuteReader();
            while (rdr.Read())
            {
                comboBox4.Items.Add(rdr.GetString(0));
                comboBox4.Text = rdr.GetString(0);
            }
            rdr.Close();
        }

        private void fill_the_spaces(int id)
        {
            SqlCommand cmd = new SqlCommand($"select [Products].[id],[art],[product_name],Unit_measuremnt.[unit_name],[price],Deliver.[deliver_name]      ,Creator.creator_name      ,Categories.category_name      ,[discont]      ,[countt]      ,[info]      ,[photo] from ((([Products] inner join Unit_measuremnt on Unit_measuremnt.id = [Products].unit_meas) inner join Deliver on Products.deliver = Deliver.id)      inner join Creator on Creator.id = Products.creator) inner join Categories on Categories.id = Products.category where [Products].[id] = '{id}'", conn);

            SqlDataReader rdr = cmd.ExecuteReader();

            if (rdr.Read())
            {
                textBox1.Text = rdr.GetString(1);
                textBox2.Text = rdr.GetString(2);
                comboBox1.Text = rdr.GetString(3);
                textBox4.Text = rdr.GetValue(4).ToString();
                comboBox2.Text = rdr.GetString(5);
                comboBox3.Text = rdr.GetString(6);
                comboBox4.Text = rdr.GetString(7);
                textBox8.Text = rdr.GetValue(9).ToString();
                textBox10.Text = rdr.GetString(10);
                try
                {
                    pictureBox1.Image = Image.FromFile(rdr.GetString(11));
                    curr_img = rdr.GetString(11);
                    way_to_img = curr_img.ToString();
                }
                catch
                {
                    pictureBox1.Image = Image.FromFile("picture.png");
                }
            }
            rdr.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofd = new OpenFileDialog())
            {
                ofd.Filter = "Изображения|*.jpg;*.jpeg;*.png";
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    using (var img = Image.FromFile(ofd.FileName))
                    {
                        if (img.Height > 320 || img.Width > 320)
                        {
                            MessageBox.Show("Изображение слишком большое, выберите изображение меньше 300 пикселей", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }
                    }
                    pictureBox1.Image = Image.FromFile(ofd.FileName);
                    curr_img = Path.GetFileName(ofd.FileName);
                    way_to_img = ofd.FileName;
                }
            }
        }

        private void change_the_img()
        {
            string filnam = Path.GetFileName(way_to_img);
            string way_to_copy = Path.Combine(Application.StartupPath, filnam);

            try
            {
                File.Copy(way_to_img, way_to_copy);
            }
            catch { }

        }

        private bool check_the_spaces()
        {
            IEnumerable<System.Windows.Forms.TextBox> textboxes = this.Controls.OfType<System.Windows.Forms.TextBox>();
            foreach (System.Windows.Forms.TextBox textBox in textboxes)
            {
                if (string.IsNullOrEmpty(textBox.Text))
                {
                    MessageBox.Show("Не все поля заполнены", "Провал!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return false;
                }
            }
            try
            {
                int pr = Convert.ToInt32(textBox4.Text);
                int cou = Convert.ToInt32(textBox8.Text);
            }
            catch 
            {
                MessageBox.Show("Неверный формат данных", "Провал!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return false;
            }
            return true;
        }

        private void save_the_changes()
        {
            if (id > 0)
            {
                SqlCommand cmd = new SqlCommand($"update Products set art = '{textBox1.Text}', product_name = N'{textBox2.Text}', unit_meas = 1, price = {textBox4.Text}, " +
                    $"[deliver] = (SELECT id FROM Deliver WHERE deliver_name = N'{comboBox2.Text}'), [creator] = (SELECT id FROM [Creator] WHERE [creator_name] = N'{comboBox3.Text}'), [category] = (SELECT id FROM [Categories] WHERE [category_name] = N'{comboBox4.Text}'), [countt] = {textBox8.Text}, [info] = N'{textBox10.Text}', [photo] = N'{curr_img}' where id = {id}", conn);
                cmd.ExecuteNonQuery();
            }
            else 
            {
                SqlCommand cmd = new SqlCommand($"insert into Products values (N'{textBox1.Text}', N'{textBox2.Text}', 1, {textBox4.Text}, " +
                    $" (SELECT id FROM Deliver WHERE deliver_name = N'{comboBox2.Text}'), (SELECT id FROM [Creator] WHERE [creator_name] = N'{comboBox3.Text}'), (SELECT id FROM [Categories] WHERE [category_name] = N'{comboBox4.Text}'), 0, N'{textBox8.Text}', N'{textBox10.Text}', N'{curr_img}')", conn);
                cmd.ExecuteNonQuery();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (check_the_spaces())
            {
                change_the_img();
                save_the_changes();

                MessageBox.Show("Данные успешно сохранены", "Успех!", MessageBoxButtons.OK, MessageBoxIcon.Information);

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            DialogResult res = MessageBox.Show("Точно удалить товар?", "подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                SqlCommand cmd = new SqlCommand($"delete from Products where id = {id}", conn);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Данные были удалены", "Успех!", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
                this.Close();
            }
        }
    }
}
