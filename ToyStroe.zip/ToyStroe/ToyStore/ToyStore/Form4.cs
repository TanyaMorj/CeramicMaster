﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ToyStore
{
    public partial class Form4 : Form
    {
        SqlConnection conn;
        public Form4()
        {
            BaseCon bc = new BaseCon();
            bc.open_connection();
            conn = bc.get_connection();
            InitializeComponent();
            fill_the_panel();
        }

        private void fill_the_panel()
        {
            panel2.Controls.Clear();
            SqlCommand cmd = new SqlCommand("select Orders.id, art, Statuses.statuss, point_address, order_date, delivery_date from ([products_and_orders] inner join (([Orders] inner join [Statuses] on Orders.statuss = Statuses.id) inner join Points on Orders.point = Points.id)\r\non products_and_orders.id_order = Orders.id) inner join Products on products_and_orders.id_product = Products.id", conn);
            SqlDataReader rdr  = cmd.ExecuteReader();
            int indx = 0;
            while (rdr.Read())
            {
                Panel pnl = new Panel();
                pnl.Tag = rdr.GetInt32(0);
                pnl.Location = new System.Drawing.Point(3, 3 + 140 * indx);
                pnl.Size = new System.Drawing.Size(775, 135);

                pnl.Controls.AddRange(new Control[] { new Label {AutoSize = true, Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))),
                    Location = new System.Drawing.Point(4, 4),
                Text = rdr.GetString(1)},
                new Label {AutoSize = true, Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))),
                    Location = new System.Drawing.Point(4, 24),
                Text = rdr.GetString(2)},
                new Label {AutoSize = true, Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))),
                    Location = new System.Drawing.Point(4, 44),
                Text = rdr.GetString(3)},
                new Label {AutoSize = true, Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))),
                    Location = new System.Drawing.Point(4, 64),
                Text = rdr.GetString(4)},
                new Label {AutoSize = true, Font = new System.Drawing.Font("Arial", 7.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204))),
                    Location = new System.Drawing.Point(480, 53),
                Text = rdr.GetString(5)},
                });

                pnl.Click += Pnl_Click;
                indx++;
                panel2.Controls.Add(pnl);
            }
        }

        private void Pnl_Click(object sender, EventArgs e)
        {
            Panel pnl = (Panel)sender;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
