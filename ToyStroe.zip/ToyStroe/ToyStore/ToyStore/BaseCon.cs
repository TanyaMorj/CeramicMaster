﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace ToyStore
{
    internal class BaseCon
    {
        SqlConnection basecon = new SqlConnection("Server=ASS3000\\ASS300;Database=Toy_store;Trusted_Connection=True;"); //;User Id=user04;Password=93499;"); // ;Trusted_Connection=True

        public void open_connection()
        {
            basecon.Open();
        }

        public void close_connection() { basecon.Close(); }
        public SqlConnection get_connection() { return basecon; }
    }
}
